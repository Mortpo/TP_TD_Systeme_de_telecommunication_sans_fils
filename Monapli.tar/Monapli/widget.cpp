#pragma comment(lib,ODALID.lib)
#include "widget.h"
#include "ui_widget.h"
#include "ODALID.h"
#include "QDebug"
#include "string"
#include "stdio.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
}

Widget::~Widget()
{
    delete ui;
}

ReaderName MonLecteur;
char pszHost[] = "192.168.1.4";

void Widget::on_Connect_clicked()
{
    unsigned char key_ff[6]={0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    unsigned char key_A2[6]={0xA0 , 0xA1,0xA2,0xA3,0xA4,0xA5};
    unsigned char key_B2[6]={0xB0 , 0xB1,0xB2,0xB3,0xB4,0xB5};
    uint16_t status = 0;
    MonLecteur.Type = ReaderCDC;
    MonLecteur.device = 0;
    status = OpenCOM(&MonLecteur);
    qDebug() << "OpendCOM1" << status;

    char version[30];
    uint8_t serial[4];
    char stackReader[20];

    status = Version(&MonLecteur,version,serial,stackReader);
    ui->Affichage->setText(version);
    ui->Affichage->update();
    std::string erreur_connexion = "64532";
    RF_Power_Control(&MonLecteur,TRUE,0);
    BYTE atq[2];
    BYTE sak[1];
    BYTE uid[12];
    uint16_t uid_len = 12;
    status = ISO14443_3_A_PollCard(&MonLecteur,atq,sak,uid,&uid_len);
    if(erreur_connexion.compare(version) < 0 && status == 0 ){
        //lecture nom prénom

        unsigned char data[16];
        //char result[16];
        //uint8_t block = 10;
        Mf_Classic_LoadKey(&MonLecteur,Auth_KeyA,key_A2,2);
        Mf_Classic_LoadKey(&MonLecteur,Auth_KeyB,key_B2,2);
        Mf_Classic_Read_Block(&MonLecteur,TRUE,10,data,Auth_KeyA,2);
        QString result = ""; //+ data[0];//QString::fromUtf8((char*)data);

        for (int i =0; i<16 ; i++) {
            result= result+data[i];
        }
        ui->Nom->setText(result);
        result = "";
        Mf_Classic_Read_Block(&MonLecteur,TRUE,9,data,Auth_KeyA,2);
        //sprintf( result, ui->Nom->toPlainText().toUtf8().data(),16);
        for (int i =0; i<16 ; i++) {
            result= result+data[i];
        }

        ui->Prenom->setText(result);
        ui->Nom->update();
        ui->Prenom->update();

    }
}


void Widget::on_Quitter_clicked()
{
    int16_t status =0;
    RF_Power_Control(&MonLecteur,FALSE,0);
    status= LEDBuzzer(&MonLecteur,LED_OFF);
    status = CloseCOM(&MonLecteur);
    qApp->quit();
}

void Widget::on_Ecriture_clicked()
{
    QString stringdataNom = ui->Nom->toPlainText();
    uint8_t data = stringdataNom.toInt();
    qDebug()<<data;
    Mf_Classic_Write_Sector(&MonLecteur,FALSE,10,&data,FALSE,12);
}
